setwd("C:\\Users\\IT24100374\\Desktop\\IT24100374")
getwd()

branch_data <- read.table("Exercise.txt", header = TRUE,sep=" ")
head(branch_data)

str(branch_data)


boxplot(branch_data$Sales_X1,main = "Boxplot of Sales",outline = TRUE,outpch=8,horizontal=TRUE)


summary(branch_data$Advertising_X2)        
fivenum(branch_data$Advertising_X2)        
IQR(branch_data$Advertising_X2)           



find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}





